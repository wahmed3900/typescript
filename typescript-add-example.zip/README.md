TypeScript `add` example

Files:
- add.ts — typed example showing correct and incorrect usage
- js — original JavaScript snippet

Quick start (compile + run):

```bash
# 1) Initialize and install TypeScript (if not already):
npm init -y
npm install --save-dev typescript

# 2) Compile the TypeScript file to JavaScript:
npx tsc add.ts

# 3) Run the compiled output:
node add.js
```

Or run directly with `ts-node` (dev dependency):

```bash
npm install --save-dev ts-node typescript
npx ts-node add.ts
```
